# Electricity Unit Price
# TODO: Define electricity price constants here

# Water Unit Price
# TODO: Define Water price constants here

# Implementation

# Input 1 Validation
# TODO: get the bill type from user
# TODO: check if bill type is valid

# Input 2 Validation
# TODO: get the meter reading from the user
# TODO: check if meter reading is valid

# Bill Calculation
# TODO: calculate and display the bill

